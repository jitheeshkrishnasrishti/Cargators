const config = {

    gmail:
    {
        host: 'mejbr333@gmail.com',
        pass: 'waqf ucur itfl zzwg'
    }
    
 
};
module.exports = config;